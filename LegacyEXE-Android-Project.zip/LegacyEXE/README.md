# LEGACY EXE — Android project

Aplikasi Android sederhana bertema hitam/ungu dengan logo yang diberikan, halaman Home, editor Lua, dan penyimpanan script lokal.

## Cara membuka
1. Ekstrak `LegacyEXE-Android-Project.zip`.
2. Buka folder `LegacyEXE` melalui Android Studio (Open).
3. Tunggu Gradle Sync selesai.
4. Jalankan ke emulator/perangkat Android melalui tombol Run.

## Batasan versi 1.0
Ini adalah editor/pengelola script Lua mandiri. Tidak ada injeksi ke Roblox, bypass keamanan, atau runtime Lua. Tombol Execute Roblox tidak disediakan. Script disimpan di localStorage WebView pada perangkat.

## Build
Butuh Android Studio dengan Android Gradle Plugin 8.7.3 dan Android SDK 35.
